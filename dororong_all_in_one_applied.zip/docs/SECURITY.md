# SECURITY
- Cloud Functions callables에 **레이트 리미트** 적용 (`_rate` 버킷)
- **감사 로그** `_audit`: 관리자/시스템 행위 기록
- **콘텐츠 필터**: 금칙어 자동 숨김/플래그
- **개인정보 도구**: export/delete callable 제공