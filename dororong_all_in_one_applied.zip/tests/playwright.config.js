// tests/playwright.config.js
export default { webServer: { command: 'npx http-server ./web -p 4173', port: 4173, timeout: 120000 } };