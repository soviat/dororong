import * as admin from "firebase-admin";
import * as functions from "firebase-functions";

admin.initializeApp();
const db = admin.firestore();

export const vitals = functions.https.onRequest(async (req, res)=>{
  try{
    const data = typeof req.body === "string" ? JSON.parse(req.body||"{}") : (req.body||{});
    await db.collection("_vitals").add({ ...data, at: admin.firestore.FieldValue.serverTimestamp() });
    res.set('Cache-Control','no-store').status(204).send();
  }catch(e){ console.error(e); res.status(500).send("error"); }
});

export const err = functions.https.onRequest(async (req, res)=>{
  try{
    const data = typeof req.body === "string" ? JSON.parse(req.body||"{}") : (req.body||{});
    await db.collection("_errors").add({ ...data, at: admin.firestore.FieldValue.serverTimestamp() });
    res.status(204).send();
  }catch(e){ console.error(e); res.status(500).send("error"); }
});